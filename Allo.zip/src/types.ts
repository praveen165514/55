export interface ScannedDocument {
  id: string;
  title: string;
  category: string;
  imageBase64?: string; // legacy support
  images?: string[];
  date: number;
}
