import { initializeApp } from "firebase/app";
import { getFirestore, initializeFirestore } from "firebase/firestore";
import { getAuth, signInWithPopup, GoogleAuthProvider, signOut } from "firebase/auth";
import firebaseConfig from "../firebase-applet-config.json";

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Use the explicit database ID if provided, otherwise default
const dbId = (firebaseConfig as any).firestoreDatabaseId;
export const db = dbId ? initializeFirestore(app, {}, dbId) : getFirestore(app);

export const signInWithGoogle = async () => {
    try {
        const provider = new GoogleAuthProvider();
        await signInWithPopup(auth, provider);
    } catch (e) {
        console.error("Google auth failed", e);
    }
};

export const logOut = async () => {
    try {
        await signOut(auth);
    } catch (e) {
        console.error("Sign out failed", e);
    }
};
