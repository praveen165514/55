import React, { useState, useRef, useEffect, KeyboardEvent } from "react";
import {
  Folder,
  FileText,
  Upload,
  Camera,
  Loader2,
  X,
  ChevronRight,
  FileDown,
  Plus,
  Check,
  Trash2,
  AlertTriangle,
  Download,
  FolderInput,
  LogOut,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { ScannedDocument } from "./types";
import { get, set } from "idb-keyval";
import JSZip from "jszip";
import { saveAs } from "file-saver";
import { compressImage } from "./imageUtils";
import { db, auth, signInWithGoogle, logOut } from "./firebase";
import { doc, setDoc, onSnapshot } from "firebase/firestore";
import { onAuthStateChanged, User } from "firebase/auth";

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [documents, setDocuments] = useState<ScannedDocument[]>([]);
  const [customFolders, setCustomFolders] = useState<string[]>([]);
  const [isScanning, setIsScanning] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [selectedDocument, setSelectedDocument] =
    useState<ScannedDocument | null>(null);
  const [isAddingFolder, setIsAddingFolder] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");
  const [documentToDelete, setDocumentToDelete] =
    useState<ScannedDocument | null>(null);
  const [folderToDelete, setFolderToDelete] = useState<string | null>(null);
  const [selectedDocIds, setSelectedDocIds] = useState<Set<string>>(new Set());
  const [isMoveModalOpen, setIsMoveModalOpen] = useState(false);
  const [moveTargetFolder, setMoveTargetFolder] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const fileBrowseRef = useRef<HTMLInputElement>(null);
  const [dataLoaded, setDataLoaded] = useState(false);

  useEffect(() => {
    let unsubSnapshot: (() => void) | undefined;
    let authInvocation = 0;

    const unsub = onAuthStateChanged(auth, (currentUser) => {
      const currentInvocation = ++authInvocation;
      setDataLoaded(false);
      setUser(currentUser);
      
      setDocuments([]);
      setCustomFolders([]);
      
      setSelectedCategory(null);
      setSelectedDocument(null);
      setDocumentToDelete(null);
      setFolderToDelete(null);
      setSelectedDocIds(new Set());
      setIsScanning(false);
      setIsMoveModalOpen(false);

      if (unsubSnapshot) {
        unsubSnapshot();
        unsubSnapshot = undefined;
      }
      if (currentUser) {
        const userDocRef = doc(db, "users", currentUser.uid);
        unsubSnapshot = onSnapshot(userDocRef, (snapshot) => {
          if (authInvocation !== currentInvocation) return;
          if (snapshot.exists()) {
            const data = snapshot.data();
            setDocuments(data.documents || []);
            setCustomFolders(data.customFolders || []);
          } else {
            setDocuments([]);
            setCustomFolders([]);
          }
          setDataLoaded(true);
        });
      } else {
        // Not signed in, load local
        get("scanner_docs")
          .then((val) => {
            if (authInvocation !== currentInvocation) return;
            if (val && val.length > 0) {
              setDocuments(val);
            } else {
              setDocuments([]);
            }
          })
          .catch(() => {
            if (authInvocation !== currentInvocation) return;
            setDocuments([]);
          })
          .finally(() => {
            if (authInvocation !== currentInvocation) return;
            const savedFolders = localStorage.getItem("scanner_folders");
            if (savedFolders) {
              try {
                setCustomFolders(JSON.parse(savedFolders));
              } catch (e) {
                setCustomFolders([]);
              }
            } else {
              setCustomFolders([]);
            }
            setDataLoaded(true);
          });
      }
    });

    return () => {
      authInvocation++;
      unsub();
      if (unsubSnapshot) unsubSnapshot();
    };
  }, []);

  useEffect(() => {
    if (!dataLoaded) return;
    if (user) {
      const userDocRef = doc(db, "users", user.uid);
      setDoc(userDocRef, { documents, customFolders }, { merge: true }).catch(
        console.error,
      );
    } else {
      set("scanner_docs", documents).catch(console.error);
      localStorage.setItem("scanner_folders", JSON.stringify(customFolders));
    }
  }, [documents, customFolders, dataLoaded, user]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsScanning(true);

    try {
      const dataUrl = await compressImage(file);
      const base64 = dataUrl.split(",")[1];

      const allCats = Array.from(
        new Set([...customFolders, ...documents.map((d) => d.category)]),
      );

      const response = await fetch("/api/scan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64: base64,
          mimeType: file.type || "image/jpeg",
          availableFolders: allCats,
        }),
      });

      if (!response.ok) {
        throw new Error(await response.text());
      }

      const result = await response.json();

      let finalTitle = result.title || "Untitled Document";
      let finalCategory = result.category || "Uncategorized";

      // Strict categorization logic based on user title
      const titleLower = finalTitle.toLowerCase();
      // 1. If the title matches an existing custom folder exactly, route it there
      const matchingFolder = customFolders.find(
        (f) => f.toLowerCase() === titleLower,
      );
      if (matchingFolder) {
        finalCategory = matchingFolder;
      } else {
        // 2. If it has the same title as an existing document, route it to that document's folder
        const existingDoc = documents.find(
          (d) => d.title.toLowerCase() === titleLower,
        );
        if (existingDoc) {
          finalCategory = existingDoc.category;
        }
      }

      const newDoc: ScannedDocument = {
        id: Date.now().toString(),
        title: finalTitle,
        category: finalCategory,
        imageBase64: dataUrl,
        images: [dataUrl],
        date: Date.now(),
      };

      setDocuments((prev) => [...prev, newDoc]);
      setSelectedCategory(newDoc.category);
      setSelectedDocument(newDoc);
    } catch (error) {
      console.error("Scan error:", error);
      alert("Failed to scan document. Please try again.");
    } finally {
      setIsScanning(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = "";
      }
      if (fileBrowseRef.current) {
        fileBrowseRef.current.value = "";
      }
    }
  };

  const triggerUpload = () => {
    fileInputRef.current?.click();
  };

  const triggerFileBrowse = () => {
    fileBrowseRef.current?.click();
  };

  const appendFileInputRef = useRef<HTMLInputElement>(null);
  const appendFileBrowseRef = useRef<HTMLInputElement>(null);

  const handleAppendFileUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];
    if (!file || !selectedDocument) return;

    setIsScanning(true);
    try {
      const dataUrl = await compressImage(file);

      setDocuments((prev) =>
        prev.map((doc) => {
          if (doc.id === selectedDocument.id) {
            const currentImages =
              doc.images || (doc.imageBase64 ? [doc.imageBase64] : []);
            const updatedDoc = { ...doc, images: [...currentImages, dataUrl] };
            setSelectedDocument(updatedDoc);
            return updatedDoc;
          }
          return doc;
        }),
      );
    } catch (error) {
      console.error("Append error:", error);
      alert("Failed to append image. Please try again.");
    } finally {
      setIsScanning(false);
      if (appendFileInputRef.current) {
        appendFileInputRef.current.value = "";
      }
      if (appendFileBrowseRef.current) {
        appendFileBrowseRef.current.value = "";
      }
    }
  };

  const categories = Array.from(
    new Set([...customFolders, ...documents.map((d) => d.category)]),
  ).sort((a, b) => a.localeCompare(b));

  const handleAddFolder = () => {
    if (newFolderName.trim()) {
      setCustomFolders((prev) =>
        Array.from(new Set([...prev, newFolderName.trim()])),
      );
      setNewFolderName("");
      setIsAddingFolder(false);
    }
  };

  const handleAddFolderKeyDown = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") handleAddFolder();
    if (e.key === "Escape") {
      setIsAddingFolder(false);
      setNewFolderName("");
    }
  };

  const documentsToShow = selectedCategory
    ? documents
        .filter((d) => d.category === selectedCategory)
        .sort((a, b) => a.title.localeCompare(b.title))
    : [];

  const handleDownload = async (doc: ScannedDocument) => {
    const images = doc.images || (doc.imageBase64 ? [doc.imageBase64] : []);
    if (images.length === 0) return;

    if (images.length === 1) {
      const response = await fetch(images[0]);
      const blob = await response.blob();
      const element = document.createElement("a");
      element.href = URL.createObjectURL(blob);
      element.download = `${doc.title.replace(/[^a-z0-9]/gi, "_").toLowerCase()}.jpg`;
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
    } else {
      const zip = new JSZip();
      images.forEach((img, idx) => {
        const base64Data = img.split(";base64,").pop();
        if (base64Data) {
          zip.file(
            `${doc.title.replace(/[^a-z0-9]/gi, "_").toLowerCase()}-page${idx + 1}.jpg`,
            base64Data,
            { base64: true },
          );
        }
      });
      const content = await zip.generateAsync({ type: "blob" });
      saveAs(
        content,
        `${doc.title.replace(/[^a-z0-9]/gi, "_").toLowerCase()}.zip`,
      );
    }
  };

  const confirmDeleteDocument = () => {
    if (documentToDelete) {
      setDocuments((prev) => prev.filter((d) => d.id !== documentToDelete.id));
      if (selectedDocument?.id === documentToDelete.id) {
        setSelectedDocument(null);
      }
      setDocumentToDelete(null);
    }
  };

  const confirmDeleteFolder = () => {
    if (folderToDelete) {
      setDocuments((prev) => prev.filter((d) => d.category !== folderToDelete));
      setCustomFolders((prev) => prev.filter((f) => f !== folderToDelete));
      if (selectedCategory === folderToDelete) {
        setSelectedCategory(null);
        setSelectedDocument(null);
      }
      setFolderToDelete(null);
    }
  };

  const handleBulkDownload = async () => {
    if (selectedDocIds.size === 0) return;
    const zip = new JSZip();

    for (const docId of selectedDocIds) {
      const doc = documents.find((d) => d.id === docId);
      if (doc) {
        const images = doc.images || (doc.imageBase64 ? [doc.imageBase64] : []);
        images.forEach((img, idx) => {
          const base64Data = img.split(";base64,").pop();
          if (base64Data) {
            const fileName =
              images.length > 1
                ? `${doc.title.replace(/[^a-z0-9]/gi, "_").toLowerCase()}-${doc.id}-page${idx + 1}.jpg`
                : `${doc.title.replace(/[^a-z0-9]/gi, "_").toLowerCase()}-${doc.id}.jpg`;
            zip.file(fileName, base64Data, { base64: true });
          }
        });
      }
    }

    const content = await zip.generateAsync({ type: "blob" });
    saveAs(content, "documents.zip");
    setSelectedDocIds(new Set());
  };

  const handleBulkMove = () => {
    if (selectedDocIds.size === 0 || !moveTargetFolder) return;
    setDocuments((prev) =>
      prev.map((doc) => {
        if (selectedDocIds.has(doc.id)) {
          return { ...doc, category: moveTargetFolder };
        }
        return doc;
      }),
    );
    if (!customFolders.includes(moveTargetFolder)) {
      setCustomFolders((prev) => [...prev, moveTargetFolder]);
    }
    setSelectedDocIds(new Set());
    setIsMoveModalOpen(false);
  };

  const toggleDocumentSelection = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedDocIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  return (
    <div className="h-screen w-full bg-[#F9F7F2] text-[#1A1A1A] flex flex-col overflow-hidden font-sans">
      {/* Header */}
      <header className="bg-white border-b-2 border-[#1A1A1A] px-4 py-2 flex flex-row items-center justify-between shrink-0 z-10 relative">
          {selectedDocument ? (
            <div className="flex items-center gap-3 overflow-hidden">
              <button
                onClick={() => setSelectedDocument(null)}
                className="p-2 -ml-2 hover:bg-neutral-100 rounded-full transition-colors flex-shrink-0"
              >
                <ChevronRight className="w-6 h-6 rotate-180" />
              </button>
              <h1 className="text-lg font-serif italic font-black truncate">
                {selectedDocument.title}
              </h1>
            </div>
          ) : selectedCategory !== null ? (
            <div className="flex items-center gap-3 overflow-hidden">
              <button
                onClick={() => {
                  setSelectedCategory(null);
                  setSelectedDocIds(new Set());
                }}
                className="p-2 -ml-2 hover:bg-neutral-100 rounded-full transition-colors flex-shrink-0"
              >
                <ChevronRight className="w-6 h-6 rotate-180" />
              </button>
              <h1 className="text-xl font-serif italic font-black truncate">
                {selectedCategory === "__ALL__"
                  ? "/All_Documents"
                  : `/${selectedCategory}`}
              </h1>
            </div>
          ) : (
            <div className="flex items-center gap-3">
              <h1 className="text-2xl font-serif italic font-black tracking-tighter">
                AUTOSCAN.
              </h1>
            </div>
          )}

          <div className="flex items-center gap-2 flex-shrink-0">
            {!user ? (
              <button
                onClick={signInWithGoogle}
                className="text-[10px] font-black uppercase tracking-widest px-3 py-1.5 border-2 border-[#1A1A1A] bg-white shadow-[2px_2px_0px_#1A1A1A] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_#1A1A1A] transition-all mr-2"
              >
                Sign In
              </button>
            ) : (
              <div className="flex items-center gap-2 mr-2">
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt=""
                    className="w-8 h-8 object-cover border-2 border-[#1A1A1A] shadow-[2px_2px_0px_#1A1A1A]"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-8 h-8 bg-[#E5FF00] border-2 border-[#1A1A1A] shadow-[2px_2px_0px_#1A1A1A]" />
                )}
                <button
                  onClick={logOut}
                  title="Sign Out"
                  className="w-8 h-8 flex flex-col items-center justify-center bg-white border-2 border-[#1A1A1A] shadow-[2px_2px_0px_#1A1A1A] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_#1A1A1A] transition-all group"
                >
                  <LogOut className="w-4 h-4 group-hover:text-red-600 transition-colors" />
                </button>
              </div>
            )}
            {isScanning || !dataLoaded ? (
              <div className="flex items-center bg-[#1A1A1A] text-[#E5FF00] px-3 py-1.5 border-2 border-[#1A1A1A] shadow-[2px_2px_0px_#1A1A1A]">
                <Loader2 className="w-4 h-4 animate-spin sm:mr-2" />
                <span className="text-[10px] font-black uppercase hidden sm:inline">Wait</span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={triggerFileBrowse}
                  disabled={isScanning || !dataLoaded}
                  title="Upload from Local Files"
                  className="flex items-center gap-1.5 p-2 sm:px-3 sm:py-1.5 bg-white text-[#1A1A1A] font-black uppercase text-[10px] tracking-widest border-2 border-[#1A1A1A] shadow-[2px_2px_0px_#1A1A1A] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_#1A1A1A] transition-all disabled:opacity-50"
                >
                  <Upload className="w-4 h-4" /> <span className="hidden sm:inline">Upload</span>
                </button>
                <button
                  onClick={triggerUpload}
                  disabled={isScanning || !dataLoaded}
                  title="Scan using Camera"
                  className="flex items-center gap-1.5 p-2 sm:px-3 sm:py-1.5 bg-[#E5FF00] text-[#1A1A1A] font-black uppercase text-[10px] tracking-widest border-2 border-[#1A1A1A] shadow-[2px_2px_0px_#1A1A1A] hover:translate-y-[1px] hover:shadow-[1px_1px_0px_#1A1A1A] transition-all disabled:opacity-50"
                >
                  <Camera className="w-4 h-4" /> <span className="hidden sm:inline">Scan</span>
                </button>
              </div>
            )}
          </div>
        </header>

        <input
          type="file"
          accept="image/*"
          capture="environment"
          ref={fileInputRef}
          className="hidden"
          onChange={handleFileUpload}
        />
        <input
          type="file"
          accept="image/*"
          ref={fileBrowseRef}
          className="hidden"
          onChange={handleFileUpload}
        />
        <input
          type="file"
          accept="image/*"
          capture="environment"
          ref={appendFileInputRef}
          className="hidden"
          onChange={handleAppendFileUpload}
        />
        <input
          type="file"
          accept="image/*"
          ref={appendFileBrowseRef}
          className="hidden"
          onChange={handleAppendFileUpload}
        />

        <main className="flex-1 w-full flex flex-col overflow-hidden relative">
          {/* View 1: Folders List */}
          {selectedCategory === null && selectedDocument === null && (
            <div className="flex-1 flex flex-col min-h-0 bg-[#F9F7F2] absolute inset-0 overflow-y-auto">
              <div className="p-4 border-b border-[#1A1A1A]/10 bg-[#F9F7F2] sticky top-0 z-10 flex flex-col gap-3">
                <div className="flex items-center justify-between mb-4 mt-2">
                  <h2 className="text-[11px] font-black uppercase tracking-[0.2em] opacity-50">
                    Auto-Categorization
                  </h2>
                  {isAddingFolder ? (
                    <div className="flex items-center gap-2">
                      <input
                        autoFocus
                        type="text"
                        value={newFolderName}
                        onChange={(e) => setNewFolderName(e.target.value)}
                        onKeyDown={handleAddFolderKeyDown}
                        className="w-24 bg-transparent border-b border-[#1A1A1A] outline-none font-serif italic text-sm pb-0.5 placeholder:opacity-40"
                        placeholder="Name"
                      />
                      <button
                        onClick={handleAddFolder}
                        className="shrink-0 p-1 bg-[#E5FF00] border border-[#1A1A1A]"
                      >
                        <Check className="w-3 h-3 text-[#1A1A1A]" />
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setIsAddingFolder(true)}
                      className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest hover:underline underline-offset-4"
                    >
                      <Plus className="w-3 h-3" /> Add Folder
                    </button>
                  )}
                </div>
              </div>
              <div className="p-4 grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10 pb-20">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategory(cat)}
                    className="flex flex-col items-center gap-1.5 p-3 pt-5 bg-white border-2 border-[#1A1A1A] cursor-pointer hover:-translate-y-1 hover:shadow-[4px_4px_0px_#1A1A1A] shadow-[2px_2px_0px_#1A1A1A] transition-all group relative"
                  >
                    <div className="absolute top-1.5 right-1.5 text-[9px] font-mono bg-[#E5FF00] text-[#1A1A1A] px-1.5 py-0.5 border border-[#1A1A1A]">
                      {documents.filter((d) => d.category === cat).length}
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setFolderToDelete(cat);
                      }}
                      className="absolute top-1.5 left-1.5 p-1 text-red-500 opacity-0 group-hover:opacity-100 hover:bg-neutral-100 transition-all border border-transparent hover:border-[#1A1A1A]"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                    <Folder className="w-8 h-8 text-[#1A1A1A] fill-[#E5FF00]" strokeWidth={1} />
                    <span className="text-[10px] font-bold text-[#1A1A1A] truncate w-full text-center mt-1">
                      {cat.replace(/\s+/g, "_")}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* View 2: Documents List in Folder */}
          {selectedCategory !== null && selectedDocument === null && (
            <div className="flex-1 flex flex-col min-h-0 bg-[#F9F7F2] absolute inset-0">
              {selectedDocIds.size > 0 ? (
                <div className="p-3 shrink-0 border-b-2 border-[#1A1A1A] flex items-center bg-[#E5FF00] gap-4 justify-between sticky top-0 z-10 transition-colors">
                  <div className="text-[10px] font-black uppercase tracking-widest text-[#1A1A1A]">
                    {selectedDocIds.size} Selected
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={handleBulkDownload}
                      className="flex items-center gap-2 px-2 py-1.5 bg-[#1A1A1A] text-white text-[10px] font-black uppercase tracking-widest active:bg-neutral-800 transition-colors border-2 border-[#1A1A1A]"
                    >
                      <Download className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => setIsMoveModalOpen(true)}
                      className="flex items-center gap-2 px-2 py-1.5 bg-white text-[#1A1A1A] text-[10px] font-black uppercase tracking-widest border-2 border-[#1A1A1A]"
                    >
                      <FolderInput className="w-3 h-3" />
                    </button>
                    <button
                      onClick={() => setSelectedDocIds(new Set())}
                      className="flex items-center gap-2 px-2 py-1.5 bg-transparent text-[#1A1A1A] text-[10px] font-black uppercase tracking-widest opacity-70"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ) : (
                selectedCategory !== "__ALL__" && (
                  <div className="p-3 shrink-0 border-b-2 border-[#1A1A1A] flex items-center bg-[#F9F7F2] justify-end sticky top-0 z-10">
                    <button
                      onClick={() => setFolderToDelete(selectedCategory)}
                      className="text-red-500 hover:text-red-700 transition-colors flex items-center gap-1.5 text-[10px] font-black uppercase tracking-widest border border-red-500/30 px-3 py-1.5 bg-red-50"
                    >
                      <Trash2 className="w-3 h-3" /> Drop Folder
                    </button>
                  </div>
                )
              )}

              <div className="flex-1 overflow-y-auto w-full bg-[#F9F7F2] pb-20 p-4">
                {(selectedCategory === "__ALL__"
                  ? documents.sort((a, b) => a.title.localeCompare(b.title))
                  : documentsToShow
                ).length === 0 ? (
                  <div className="flex flex-col items-center justify-center p-8 text-center bg-white border-2 border-dashed border-[#1A1A1A]/30 min-h-[300px]">
                    <FileText className="w-10 h-10 text-[#1A1A1A]/30 mb-4" />
                    <p className="font-serif italic text-xl mb-2">
                      Folder is empty
                    </p>
                    <p className="text-[10px] font-mono text-[#1A1A1A]/60 uppercase tracking-widest">
                      Scan a document to add
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10">
                    {(selectedCategory === "__ALL__"
                      ? documents.sort((a, b) => a.title.localeCompare(b.title))
                      : documentsToShow
                    ).map((doc) => {
                      const isSelected = selectedDocIds.has(doc.id);
                      return (
                        <div
                          key={doc.id}
                          onClick={() => setSelectedDocument(doc)}
                          className={`flex flex-col items-center gap-1 p-2 pt-4 bg-white border-2 border-[#1A1A1A] cursor-pointer hover:-translate-y-1 hover:shadow-[4px_4px_0px_#1A1A1A] transition-all group relative ${isSelected ? "shadow-[0px_0px_0px_2px_#E5FF00] top-[-2px]" : "shadow-[2px_2px_0px_#1A1A1A]"}`}
                        >
                          <div
                            className="absolute top-1 left-1 z-10"
                            onClick={(e) => toggleDocumentSelection(doc.id, e)}
                          >
                            <div
                              className={`w-4 h-4 border flex items-center justify-center transition-colors ${isSelected ? "bg-[#E5FF00] border-[#1A1A1A]" : "border-[#1A1A1A]/30 bg-white group-hover:border-[#1A1A1A] opacity-0 group-hover:opacity-100"} ${isSelected ? "opacity-100" : ""}`}
                            >
                              {isSelected && (
                                <Check className="w-3 h-3 text-[#1A1A1A] stroke-[3]" />
                              )}
                            </div>
                          </div>
                          <div className="absolute top-1 right-1 text-[8px] font-mono bg-white border border-[#1A1A1A] px-1 py-px shadow-[1px_1px_0px_#1A1A1A]">
                            {doc.images?.length || (doc.imageBase64 ? 1 : 0)} Pg
                          </div>
                          <FileText className="w-8 h-8 text-[#1A1A1A] fill-[#EFECE5]" strokeWidth={1} />
                          <span className="text-[10px] font-bold text-[#1A1A1A] truncate w-full text-center mt-1" title={doc.title}>
                            {doc.title}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* View 3: Document Details */}
          {selectedDocument !== null && (
            <div className="flex-1 flex flex-col bg-[#EFECE5] absolute inset-0">
              <div className="px-4 py-3 border-b-2 border-[#1A1A1A] bg-white flex items-center justify-between sticky top-0 z-10 shrink-0">
                <div className="flex gap-2 sm:gap-3 shrink-0">
                  <button
                    onClick={() => appendFileBrowseRef.current?.click()}
                    title="Upload Local File"
                    className="flex items-center justify-center gap-2 p-2 sm:px-4 sm:py-2 bg-white text-[#1A1A1A] text-[10px] font-black uppercase tracking-widest border-2 border-[#1A1A1A] shadow-[2px_2px_0px_#1A1A1A] active:shadow-none active:translate-y-[2px] transition-all"
                  >
                    <Upload className="w-3 h-3" /> <span className="hidden sm:inline">Page</span>
                  </button>
                  <button
                    onClick={() => appendFileInputRef.current?.click()}
                    title="Scan using Camera"
                    className="flex items-center justify-center gap-2 p-2 sm:px-4 sm:py-2 bg-[#E5FF00] text-[#1A1A1A] text-[10px] font-black uppercase tracking-widest border-2 border-[#1A1A1A] shadow-[2px_2px_0px_#1A1A1A] active:shadow-none active:translate-y-[2px] transition-all"
                  >
                    <Camera className="w-3 h-3" /> <span className="hidden sm:inline">Page</span>
                  </button>
                  <button
                    onClick={() => handleDownload(selectedDocument)}
                    className="flex items-center justify-center gap-2 p-2 sm:px-4 sm:py-2 bg-[#1A1A1A] text-white text-[10px] font-black uppercase tracking-widest border-2 border-[#1A1A1A] shadow-[2px_2px_0px_#1A1A1A] active:shadow-none active:translate-y-[2px] transition-all"
                  >
                    <FileDown className="w-3 h-3" /> <span className="hidden sm:inline">Save</span>
                  </button>
                </div>
                <button
                  onClick={() => setDocumentToDelete(selectedDocument)}
                  className="flex items-center justify-center p-2 bg-red-100 text-red-600 active:bg-red-500 active:text-white transition-colors border-2 border-red-500 shadow-[2px_2px_0px_#ef4444]"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="p-4 flex-1 overflow-y-auto flex flex-col items-center gap-6 pb-20">
                {(
                  selectedDocument.images ||
                  (selectedDocument.imageBase64
                    ? [selectedDocument.imageBase64]
                    : [])
                ).length > 0 ? (
                  (
                    selectedDocument.images ||
                    (selectedDocument.imageBase64
                      ? [selectedDocument.imageBase64]
                      : [])
                  ).map((img, idx) => (
                    <div
                      key={idx}
                      className="relative w-full bg-white p-2 border-2 border-[#1A1A1A] shadow-[4px_4px_0px_#1A1A1A]"
                    >
                      <div className="absolute -left-3 -top-3 w-8 h-8 rounded-full bg-[#E5FF00] border-2 border-[#1A1A1A] text-[#1A1A1A] flex items-center justify-center text-xs font-black z-10 shadow-[2px_2px_0px_#1A1A1A]">
                        {idx + 1}
                      </div>
                      <img
                        src={img}
                        alt={`${selectedDocument.title} - Page ${idx + 1}`}
                        className="w-full h-auto object-contain bg-white"
                      />
                    </div>
                  ))
                ) : (
                  <div className="text-center opacity-40 my-auto p-8">
                    <Camera className="w-8 h-8 mx-auto mb-4" />
                    <p className="font-serif italic text-xl">No image data</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </main>

        {/* Delete Document Modal */}
        <AnimatePresence>
          {documentToDelete && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm"
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                className="bg-white border-2 border-[#1A1A1A] shadow-[8px_8px_0px_#1A1A1A] max-w-sm w-full relative overflow-hidden flex flex-col"
              >
                <div className="absolute top-0 left-0 w-full h-2 bg-red-500"></div>
                <div className="p-6">
                  <div className="flex items-center gap-4 mb-6 mt-2">
                    <div className="w-12 h-12 bg-red-100 flex items-center justify-center border-2 border-red-200">
                      <AlertTriangle className="w-6 h-6 text-red-500" />
                    </div>
                    <h3 className="text-2xl font-serif italic font-bold leading-tight">
                      Delete Document?
                    </h3>
                  </div>
                  <p className="text-sm opacity-80 mb-8 leading-relaxed">
                    Permanently delete{" "}
                    <span className="font-bold">
                      "{documentToDelete.title}"
                    </span>
                    ? This cannot be undone.
                  </p>
                  <div className="flex gap-4">
                    <button
                      onClick={() => setDocumentToDelete(null)}
                      className="flex-1 py-4 px-2 border-2 border-[#1A1A1A] text-[10px] font-black uppercase tracking-widest active:bg-neutral-100 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={confirmDeleteDocument}
                      className="flex-1 py-4 px-2 bg-red-500 text-white border-2 border-[#1A1A1A] text-[10px] font-black uppercase tracking-widest active:bg-red-600 transition-colors shadow-[2px_2px_0px_#1A1A1A]"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Delete Folder Modal */}
        <AnimatePresence>
          {folderToDelete && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm"
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                className="bg-white border-2 border-[#1A1A1A] shadow-[8px_8px_0px_#1A1A1A] max-w-sm w-full relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-2 bg-red-500"></div>
                <div className="p-6">
                  <div className="flex items-center gap-4 mb-6 mt-2">
                    <div className="w-12 h-12 bg-red-100 flex items-center justify-center border-2 border-red-200">
                      <Trash2 className="w-6 h-6 text-red-500" />
                    </div>
                    <h3 className="text-2xl font-serif italic font-bold leading-tight">
                      Delete Folder?
                    </h3>
                  </div>
                  <p className="text-sm opacity-80 mb-8 leading-relaxed">
                    Permanently delete{" "}
                    <span className="font-bold">"{folderToDelete}"</span> and
                    all documents inside?
                  </p>
                  <div className="flex gap-4">
                    <button
                      onClick={() => setFolderToDelete(null)}
                      className="flex-1 py-4 px-2 border-2 border-[#1A1A1A] text-[10px] font-black uppercase tracking-widest active:bg-neutral-100 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={confirmDeleteFolder}
                      className="flex-1 py-4 px-2 bg-red-500 text-white border-2 border-[#1A1A1A] text-[10px] font-black uppercase tracking-widest active:bg-red-600 transition-colors shadow-[2px_2px_0px_#1A1A1A]"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Move Documents Modal */}
        <AnimatePresence>
          {isMoveModalOpen && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 z-50 flex items-center justify-center p-6 bg-black/60 backdrop-blur-sm"
            >
              <motion.div
                initial={{ scale: 0.95, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.95, opacity: 0, y: 20 }}
                className="bg-white border-2 border-[#1A1A1A] shadow-[8px_8px_0px_#1A1A1A] max-w-sm w-full relative overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-full h-2 bg-[#E5FF00]"></div>
                <div className="p-6">
                  <div className="flex items-center gap-4 mb-6 mt-2">
                    <div className="w-12 h-12 bg-[#E5FF00]/20 flex items-center justify-center border-2 border-[#1A1A1A]/10">
                      <FolderInput className="w-6 h-6 text-[#1A1A1A]" />
                    </div>
                    <h3 className="text-2xl font-serif italic font-bold">
                      Move {selectedDocIds.size} Docs
                    </h3>
                  </div>
                  <div className="mb-8">
                    <label className="text-[10px] font-black uppercase tracking-widest mb-3 block">
                      Destination Folder
                    </label>
                    <input
                      type="text"
                      value={moveTargetFolder}
                      onChange={(e) => setMoveTargetFolder(e.target.value)}
                      className="w-full bg-[#EFECE5] border-2 border-[#1A1A1A] p-4 text-sm font-medium outline-none placeholder:opacity-50"
                      placeholder="Folder Name"
                      autoFocus
                    />
                  </div>
                  <div className="flex gap-4">
                    <button
                      onClick={() => {
                        setIsMoveModalOpen(false);
                        setMoveTargetFolder("");
                      }}
                      className="flex-1 py-4 px-2 border-2 border-[#1A1A1A] text-[10px] font-black uppercase tracking-widest active:bg-neutral-100 transition-colors"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleBulkMove}
                      disabled={!moveTargetFolder.trim()}
                      className="flex-1 py-4 px-2 bg-[#1A1A1A] text-[#E5FF00] border-2 border-[#1A1A1A] text-[10px] font-black uppercase tracking-widest disabled:opacity-50 shadow-[2px_2px_0px_#1A1A1A]"
                    >
                      Move
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
    </div>
  );
}
